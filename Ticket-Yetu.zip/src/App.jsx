import { BrowserRouter, Routes, Route, Link } from "react-router-dom";

import SportsPage from "./Components/SportsPage";
import EntertainmentPage from "./Components/EntertainmentPage";
import EventDetailsPage from "./Components/EventDetailsPage";

import Navigation from "./Components/Navigation";
import Info from "./Components/Info";
import Instructions from "./Components/Instructions";
import Registration from "./Components/registration";
import Footer from "./Components/Footer";
import Login from "./Components/Login";
import Blog from "./Components/Blog";
import Sign from "./Components/Sign";
import Help from "./Components/Help";

import ".//Components/Navigation.css";

function HomePage() {
  return (
    <div
      style={{
        minHeight: "100vh",
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
        textAlign: "center",
        padding: "40px 20px",
        background:
          "radial-gradient(circle at top, #1e293b 0%, #0f172a 45%, #020617 100%)",
        color: "white",
      }}
    >
      <h1 style={{ fontSize: "4rem", marginBottom: "16px" }}>🎟️ Ticket Yetu</h1>

      <p
        style={{
          maxWidth: "700px",
          fontSize: "1.1rem",
          lineHeight: 1.7,
          color: "#cbd5e1",
          marginBottom: "32px",
        }}
      >
        Discover and book the best sports, music, comedy, and festival events
        happening across Kenya.
      </p>

      <div
        style={{
          display: "flex",
          gap: "20px",
          flexWrap: "wrap",
          justifyContent: "center",
        }}
      >
        <Link
          to="/sports"
          style={{
            background: "#2563eb",
            color: "white",
            padding: "14px 28px",
            borderRadius: "12px",
            textDecoration: "none",
            fontWeight: "700",
            boxShadow: "0 10px 25px rgba(37,99,235,0.35)",
          }}
        >
          🏆 View Sports Events
        </Link>

        <Link
          to="/entertainment"
          style={{
            background: "#7c3aed",
            color: "white",
            padding: "14px 28px",
            borderRadius: "12px",
            textDecoration: "none",
            fontWeight: "700",
            boxShadow: "0 10px 25px rgba(124,58,237,0.35)",
          }}
        >
          🎵 View Entertainment Events
        </Link>
      </div>
    </div>
  );
}

function OrganizerHome() {
  return (
    <>
      <Info />
      <Instructions />
      <Registration />
    </>
  );
}

function OrganizerLayout() {
  return (
    <div>
      <Navigation />

      <Routes>
        <Route path="/organizer" element={<OrganizerHome />} />
        <Route path="/organizer/promoters" element={<OrganizerHome />} />
        <Route path="/organizer/blog" element={<Blog />} />
        <Route path="/organizer/login" element={<Login />} />
        <Route path="/organizer/signup" element={<Sign />} />
        <Route path="/organizer/help" element={<Help />} />
      </Routes>

      <Footer />
    </div>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        {/* Public Event Pages */}
        <Route path="/" element={<HomePage />} />
        <Route path="/sports" element={<SportsPage />} />
        <Route path="/entertainment" element={<EntertainmentPage />} />
        <Route path="/events/:id" element={<EventDetailsPage />} />

        {/* Organizer Section */}
        <Route path="/organizer/*" element={<OrganizerLayout />} />

        {/* 404 */}
        <Route
          path="*"
          element={
            <div
              style={{
                minHeight: "100vh",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                flexDirection: "column",
                textAlign: "center",
                background:
                  "radial-gradient(circle at top, #111827 0%, #020617 100%)",
                color: "white",
              }}
            >
              <h1 style={{ fontSize: "3rem", marginBottom: "12px" }}>404</h1>
              <p style={{ color: "#cbd5e1" }}>
                The page you are looking for does not exist.
              </p>
            </div>
          }
        />
      </Routes>
    </BrowserRouter>
  );
}
