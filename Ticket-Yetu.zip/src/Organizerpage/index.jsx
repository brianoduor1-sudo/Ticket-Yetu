import { Routes, Route } from "react-router-dom";
import Navigation from "./Navigation";
import Info from "./Info";
import "./Navigation.css";
import Instructions from "./Instructions";
import Registration from "./registration";
import Footer from "./Footer";
import Login from "./Login";

function Home() {
  return (
    <>
      <Info />
      <Instructions />
      <Registration />
    </>
  );
}

function OrganizerPage() {
  return (
    <div>
      <Navigation />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/login" element={<Login />} />
        <Route path="/Footer" element={<Footer />} />
        <Route path="/Instructions" element={<Instructions />} />
        <Route path="/registration" element={<Registration />} />
        <Route path="/Info" element={<Info />} />
        <Route path="/organizer" element={<organizer />} />
      </Routes>
      <Footer />
    </div>
  );
}

export default OrganizerPage;